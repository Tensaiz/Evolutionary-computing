
#Colors
BLACK = (0, 0, 0)

#Directions
RIGHT = 1
LEFT = 0

#Movements types
STANDING = 0

START_RUNNING = 1

RUNNING_STEP1 = 2
RUNNING_STEP2 = 3

JUMPING = 4

SHOOTING = 6
SHOOTING_JUMPING = 5

HURTING = 7
